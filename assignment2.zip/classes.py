###
### Group 21
###


##modules
from re import L
import pandas as pd
import pyodbc as db
from conn import conn


##classes
class metatable:
    def __init__(self):
        self.df = pd.DataFrame({
            "npl_publn_id":[],
            "authors":[],
            "title":[],
            "volume":[],
            "issue":[],
            "pages":[],
            "publication_year":[],
            "publication_month":[],
            "issn":[],
            "isbn":[],
            "xp":[],
            "doi":[]
        })

    def addEntry(self,id,author,title,volume,issue,pages,year,month,issn,isbn,xp,doi):
        row = pd.DataFrame({'npl_publn_id':[id],'authors':[author],'title':[title],'volume':[volume],'issue':[issue],'pages':[pages],'publication_year':[year],'publication_month':[month],'issn':[issn],'isbn':[isbn],'xp':[xp],'doi':[doi]})
        self.df = pd.concat([self.df,row], ignore_index=True)

    def addToDatabase(self,table_name):
        pass

    def toCSV(self):
        self.df.to_csv('metadata_table.csv')
        print(f"Metadata table written to file 'metadata_table.csv'")