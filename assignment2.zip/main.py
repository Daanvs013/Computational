###
### Group 21
###


## modules
import pyodbc as db
import pandas as pd
from functions import getISBN, getISSN, getPages, removeSpaces, getXP, getIssue, getVol, getAuthor, getTitle, getMonth, getYear
from classes import metatable
from conn import conn


##r etrieve dataset from the databse
sample_size = 100000
sql_query = 'select * from Patstat'
df = pd.read_sql(sql_query,conn).head(sample_size)

def main(dataset):
    metadata = metatable()
    num = len(dataset)

    for index,row in dataset.iterrows():
        print(f'{index+1}/{num} rows done.')

        ## clean data
        dataset.loc[index]['npl_biblio'] = removeSpaces(row['npl_biblio'])

        ## extract metadata
        metadata.addEntry(row['npl_publn_id'],getAuthor(row['npl_biblio']),getTitle(row['npl_biblio']),getVol(row['npl_biblio']),getIssue(row['npl_biblio']),getPages(row['npl_biblio']),getYear(row['npl_biblio']),getMonth(row['npl_biblio']),getISSN(row['npl_biblio']),getISBN(row['npl_biblio']),getXP(row['npl_biblio']),1)
    
    metadata.toCSV()

## run main function
main(df)
## close connection
conn.close()