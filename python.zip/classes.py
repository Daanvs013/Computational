###
### Group 21
###


##modules
from re import L
import pandas as pd
import pyodbc as db
from conn import conn
import os


##classes
class metatable:
    def __init__(self,name):
        self.df = pd.DataFrame({
            "npl_publn_id":[],
            "authors":[],
            "title":[],
            "volume":[],
            "issue":[],
            "pages":[],
            "publication_year":[],
            "publication_month":[],
            "issn":[],
            "isbn":[],
            "xp":[]
        })
        self.name = name

    def addEntry(self,id,author,title,volume,issue,pages,year,month,issn,isbn,xp):
        row = pd.DataFrame({'npl_publn_id':[id],'authors':[author],'title':[title],'volume':[volume],'issue':[issue],'pages':[pages],'publication_year':[year],'publication_month':[month],'issn':[issn],'isbn':[isbn],'xp':[xp]})
        self.df = pd.concat([self.df,row], ignore_index=True)

    def addToDatabase(self):
        pass

    def deleteFromDatabase(self):
        pass

    def toCSV(self):
        self.df.to_csv(f'{self.name}.csv')
        print(f"---- Metadata table written to file {os.getcwd()}\{self.name}.csv")

class clustertable:
    def __init__(self,name):
        self.df = pd.DataFrame({
            "npl_publn_id":[],
            "cluster_id":[],
            "npl_biblio":[]
        })
        self.name = name

    def addEntry(self,id,cluster,text):
        row = pd.DataFrame({"npl_publn_id":[id],"cluster_id":[cluster],"npl_biblio":[text]})
        self.df = pd.concat([self.df,row], ignore_index=True)

    def addToDatabase(self):
        pass

    def deleteFromDatabase(self):
        pass

    def toCSV(self):
        self.df.to_csv(f'{self.name}.csv')
        print(f"---- Final results written to file {os.getcwd()}\{self.name}.csv")