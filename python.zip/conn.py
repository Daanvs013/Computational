###
### Group 21
###


## modules
import pyodbc as db

## establish connection
server= 'uvtsql.database.windows.net'
database = 'db3'
user = 'user97'
db_password = 'CompEco1234'

conn = db.connect('Driver={SQL Server};'
                f'Server={server};'
                f'Database={database};'
                f'uid={user};'
                f'pwd={db_password};')