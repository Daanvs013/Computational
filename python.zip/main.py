###
### Group 21
###


## modules
import pyodbc as db
import pandas as pd
from functions import getISBN, getISSN, getPages, cleanString, getXP, getIssue, getVol, getAuthor, getTitle, getMonth, getYear, getScore
from classes import metatable, clustertable
from timeit import default_timer as timer
from conn import conn


## retrieve dataset from the databse
data_set = 'Patstat'
sql_query = f'select * from {data_set}'
sample_size = pd.read_sql(f'select count(*) from {data_set}',conn).loc[0][0]
n = input("How many samples should we run? insert 'all' for the entire dataset")
if n != 'all':
    sample_size = int(n)
df = pd.read_sql(sql_query,conn).head(sample_size)
print(f'---- data set: {data_set}')
print(f'---- Sample size: {sample_size}')


def main(dataset):
    t = timer() ## start timer

    ## hoe verbeteren: matching regels en metadata uit de string halen

    metadata = metatable('metadata_table')
    cluster = clustertable('cluster_table')
    num = len(dataset)

    ## metadata
    for index,row in dataset.iterrows():
        ## print
        if (index+1 == num):
            print(f'---- Creating metadata: {round(100*(index+1)/num,2)}% done, time elapsed: {round(timer() - t,2)} seconds.')
        else:
            print(f'---- Creating metadata: {round(100*(index+1)/num,2)}% done, time elapsed: {round(timer() - t,2)} seconds.', end='\r')

        ## clean data
        cleaned_row = cleanString(row['npl_biblio'])
        dataset.at[index,'npl_biblio'] = cleaned_row

        ## extract metadata
        metadata.addEntry(row['npl_publn_id'],getAuthor(row['npl_biblio']),getTitle(row['npl_biblio']),getVol(row['npl_biblio']),getIssue(row['npl_biblio']),getPages(row['npl_biblio']),getYear(row['npl_biblio']),getMonth(row['npl_biblio']),getISSN(row['npl_biblio']),getISBN(row['npl_biblio']),getXP(row['npl_biblio']))
        cluster.addEntry(row['npl_publn_id'],None,cleaned_row)

    metadata.toCSV() ## print output to a csv table

    ## matching
    t = timer() ## restart timer
    metadata.df['cluster_id'] = None ## add cluster_id column
    helper = metadata.df.copy(deep=True) ## creat helper table which is its own table in memory, not a reference to the metadata table in memory
    current_id = 1

    ## matching structure
    ## (1) get the first row that does not yet have a cluster id (from the metadata table)
    ## (2) apply a getScore function on the rows(helper table)
    ## (3) if score is good enough, add the current cluster id to the row (in the metadata table)
    ## (4) increment the current id with 1
    ## (5) go back to step 1, unless all rows have been assigned a cluster id
    for index in range(0,num):
        row = metadata.df.iloc[index]
        ## print
        if (index == num-2):
            ## last row
            print(f'---- Creating clusters: {round(100*(index+1)/(num-1),2)}% done, time elapsed: {round(timer() - t,2)} seconds.')
        else:
            print(f'---- Creating clusters: {round(100*(index+1)/(num-1),2)}% done, time elapsed: {round(timer() - t,2)} seconds.', end='\r')

        ## check if row already has a cluster assigned to it
        if row['cluster_id'] == None:
            ## match/score metadata against other rows that do not yet have a cluster id
            ## all rows in helper table are not yet assigned to a cluster id
            ## dropping rows in helper table does not influence the 'index' of the other rows in the helper table
            matches = [] 

            ##""" time to create clusters ~133seconds
            temp = helper[(helper.apply(lambda row2: getScore(row,{'npl_publn_id':row2['npl_publn_id'],'authors':row2['authors'],'title':row2['title'],'volume':row2['volume'],'issue':row2['issue'],'pages':row2['pages'],'publication_year':row2['publication_year'],'publication_month':row2['publication_month'],'issn':row2['issn'],'isbn':row2['isbn'],'xp':row2['xp']}),axis=1)) == True]
            for x,row2 in temp.iterrows():
                matches.append(x)
            ##"""
            
            """ time to create clusters ~280seconds
            for index2,row2 in helper.iterrows():
                if index2 == index: ## can't match/score to itself
                    continue
                else:
                    good_match = getScore(row,row2)
                    if good_match == True:
                        matches.append(index2)
            """
            

            ## for all matches, update cluster id and remove from helper table
            for match in matches:
                metadata.df.at[match,'cluster_id'] = current_id
                helper = helper.drop(match)
            ##increment current_id
            current_id += 1


    ## add cluster_id column to the cluster table
    cluster.df['cluster_id'] = metadata.df['cluster_id']
    cluster.toCSV()
        

## run main function
main(df)
## close connection
conn.close()