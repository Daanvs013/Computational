###
### Group 21
###


## modules
import pyodbc as db
import pandas as pd
pd.options.mode.chained_assignment = None
from functions import getISBN, getISSN, getPages, cleanString, getXP, getIssue, getVol, getAuthor, getTitle, getMonth, getYear, getScore
from classes import metatable, clustertable
from timeit import default_timer as timer
from conn import conn


## retrieve dataset from the databse
sample_size = 100
data_set = 'Patstat'
sql_query = f'select * from {data_set}'
df = pd.read_sql(sql_query,conn).head(sample_size)
print(f'---- Sample size: {sample_size}')
print(f'---- data set: {data_set}')

def main(dataset):
    t = timer() ## start timer

    ## hoe verbeteren: matching regels

    metadata = metatable()
    cluster = clustertable()
    helper = metatable()
    num = len(dataset)

    ## metadata
    for index,row in dataset.iterrows():
        ##fancy print
        if (index+1 == num):
            print(f'---- Creating metadata: {round(100*(index+1)/num,2)}% done, took {round(timer() - t,4)} seconds.')
        else:
            print(f'---- Creating metadata: {round(100*(index+1)/num,2)}% done', end='\r')

        ## clean data
        cleaned_row = cleanString(row['npl_biblio'])
        dataset.loc[index]['npl_biblio'] = cleaned_row

        ## extract metadata
        metadata.addEntry(row['npl_publn_id'],getAuthor(row['npl_biblio']),getTitle(row['npl_biblio']),getVol(row['npl_biblio']),getIssue(row['npl_biblio']),getPages(row['npl_biblio']),getYear(row['npl_biblio']),getMonth(row['npl_biblio']),getISSN(row['npl_biblio']),getISBN(row['npl_biblio']),getXP(row['npl_biblio']),1)
        cluster.addEntry(row['npl_publn_id'],None,cleaned_row)
    metadata.toCSV()

    ## matching
    t = timer() ## restart timer
    metadata.df['cluster_id'] = None ## add cluster_id column
    helper = metadata.df.copy(deep=True) ## creat helper table which is its own table in memory, not a reference to the metadata table in memory
    ## first iteration
    ## add cluster id = 1 to first row
    current_id = 1
    metadata.df.loc[0]['cluster_id'] = current_id


    ## matching structure
    ## (1) get the metadata of the first row(in metadata) that has the current cluster id
    ## (2) match all other rows in the helper table to the metadata in the previous step
    ## (3) update the cluster id in these rows if the match is good enough
    ## (4) remove the updated rows from the helper table
    ## (5) increment current id with 1
    ## (6) assign the newly incremented cluster id to a random row(in metatable) which does not yet have a cluster id
    ## (7) repeat untill all rows(in metadata) have a cluster id
    ## (8) create cluster table with the name variants and the cluster ids
    threshold_score = 4 ## choose threshold (= number of similiar metadata )
    for index,row in metadata.df.iterrows():

        ##fancy print
        if (index+1 == num):
            ## last row
            print(f'---- Creating clusters: {round(100*(index+1)/num,2)}% done, took {round(timer() - t,4)} seconds.')
        else:
            print(f'---- Creating clusters: {round(100*(index+1)/num,2)}% done', end='\r')

        if row['cluster_id'] == None:
            to_update = []
            ## match current metadata row to other rows
            for index2,row2 in helper.iterrows():
                if row2['cluster_id'] == None:
                    ## get score based on matching meta data
                    score = getScore(row,row2)
                    ## append index to list if good enough score
                    if score > threshold_score:
                        to_update.append(index2)
                    else:
                        pass
                else:
                    continue
            ## set all cluster_id to current_id where there was a good enough score/match
            for update in to_update:
                metadata.df.loc[update] = current_id
                ## remove updated row from the helper table
                helper.drop(index=update)
            

            
            ## increment current id
            current_id += 1
        else:
            continue

    ## add cluster_id column to the cluster table
    cluster.df['cluster_id'] = metadata.df['cluster_id']
    cluster.toCSV()
        

## run main function
main(df)
## close connection
conn.close()