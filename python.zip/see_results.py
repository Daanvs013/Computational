###
### Group 21
###


## modules
import pandas as pd


df = pd.read_csv('cluster_table.csv')
df = df.drop(df.columns[0],axis=1)

result = df[df['cluster_id'] == 304]
print(result.to_markdown())